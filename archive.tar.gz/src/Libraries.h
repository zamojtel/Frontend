#ifndef LIBRARIES_HEADER
#define LIBRARIES_HEADER

#define FMT_HEADER_ONLY
#include <fmt/core.h>

#endif