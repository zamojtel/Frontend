W projekcie wykorzystuje biblioteke do formatowania napisow fmt: https://github.com/fmtlib/fmt .

Katalog lib zawiera skompilowana biblioteke fmt oraz includy.

Kompilator napisalem samodzielnie.

W katalogu src znajduja sie glowne pliki projektu oraz te wygenerowane przez bnfc.

Projekt zawiera tester.
Budowanie/Testowanie:
make
python3 Tests/Tester.py

Czyszczenie testow:
make clean

W przypadku syntax errors dodalem jedynie wypisywany w pierwszej linii komunikat ERROR
reszta pochodzi z parsera.

Przypadki testowe w ktorych nie kazda sciezka zwraca wartosc, 
zwracaja informacje postaci:
Not all possible paths return values in a function called: {function_name}
bez podawania informacji o linijce bledu (efekt zamierzony)

Generuje 2 pliki:
latc_llvm oraz latc
